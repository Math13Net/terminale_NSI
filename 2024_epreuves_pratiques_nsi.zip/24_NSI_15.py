def binaire(a):
    '''convertit un nombre entier a en sa representation 
    binaire sous forme de chaine de caractères.'''
    if a == 0:
        return ... 
    bin_a = ... 
    while ... : 
        bin_a = ... + bin_a 
        a = ... 
    return bin_a


