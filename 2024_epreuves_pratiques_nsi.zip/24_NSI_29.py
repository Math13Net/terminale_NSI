def ligne_suivante(ligne):
    '''Renvoie la ligne suivant ligne du triangle de Pascal'''
    ligne_suiv = [...] 
    for i in range(...): 
        ligne_suiv.append(...) 
    ligne_suiv.append(...) 
    return ligne_suiv

def pascal(n):
    '''Renvoie le triangle de Pascal de hauteur n'''
    triangle = [ [1] ]
    for k in range(...): 
        ligne_k = ... 
        triangle.append(ligne_k)
    return triangle


